import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ccapi',
  templateUrl: './ccapi.component.html',
  styleUrls: ['./ccapi.component.scss']
})
export class CcapiComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
